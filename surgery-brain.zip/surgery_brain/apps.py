from django.apps import AppConfig


class SurgeryBrainConfig(AppConfig):
    name = 'surgery_brain'
